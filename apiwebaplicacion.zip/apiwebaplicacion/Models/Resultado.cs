﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace apiwebaplicacion.Models
{
    public class Resultado
    {
        public object DatoAdicinal {  get; set; }
        public string CodigoResultado { get; set;}
    }
}