﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace apiwebaplicacion.Models
{
    public class UsuarioLogin
    {
        public string token {  get; set; }
        public string tiempoExpira {  get; set; }

    }
}