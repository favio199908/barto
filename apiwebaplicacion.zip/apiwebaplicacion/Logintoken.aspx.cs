﻿using apiwebaplicacion.Models;
using apiwebaplicacion.Servicios;
using System;

namespace apiwebaplicacion
{
    public partial class Logintoken : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los campos de texto
            string usuario = txtUsuario.Text;
            string contraseña = txtContraseña.Text;

            // Crear una instancia del servicioAutentificar
            servicioAutentificar oservicioAutentificar = new servicioAutentificar();

            // Llamar al método RecuperaToken del servicioAutentificar
            UsuarioLogin ousuarioLogin = oservicioAutentificar.RecuperaToken(usuario, contraseña);

            // Aquí puedes realizar alguna acción adicional con el usuario obtenido, como redirigir a una página principal, etc.
            lblTokenRecuperado.Text = ousuarioLogin.token;
        }

        protected void btnRecuperarToken_Click(object sender, EventArgs e)
        {
            // Aquí puedes agregar la lógica para recuperar el token (como se mostró anteriormente)
            // Puedes usar la etiqueta lblTokenRecuperado para mostrar el resultado
        }
    }
}
